var commPaths = [{
    name: '圆点',
    "children": [{
            "children": [],
            "name": "4283960785744283"
        },
        {
            "children": [],
            "name": "4283838387745864"
        },
        {
            "children": [],
            "name": "4283924026579682"
        },
        {
            "children": [{
                "children": [],
                "name": "4283945057153135"
            }],
            "name": "4283875661923044"
        },
        {
            "children": [],
            "name": "4283936220119178"
        }
    ]
}];